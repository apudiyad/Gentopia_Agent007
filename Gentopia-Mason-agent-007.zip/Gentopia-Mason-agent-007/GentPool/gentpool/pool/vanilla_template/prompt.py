### Define your custom prompt here. Check prebuilts in gentopia.prompt :)###
from gentopia.prompt import *
from gentopia import PromptTemplate
