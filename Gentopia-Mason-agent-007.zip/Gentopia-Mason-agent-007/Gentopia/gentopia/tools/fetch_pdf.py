# fetch_pdf.py

from typing import Any
from gentopia.tools.basetool import *
import requests

class FetchPdfDirectlyArgs(BaseModel):
    pdf_link: str = ...

class FetchPdfDirectly(BaseTool):
    """Tool for fetching PDF content directly from a given link."""

    name = "fetch_pdf_directly"
    description = "Fetch PDF content directly from a given link."

    args_schema: Optional[Type[BaseModel]] = FetchPdfDirectlyArgs

    def _run(self, pdf_link: str) -> Any:
        pdf_content = fetch_pdf_content(pdf_link)
        return {"summary": pdf_content}

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError

def fetch_pdf_content(pdf_link):
    try:
        response = requests.get(pdf_link)
        response.raise_for_status()  # Raise HTTPError for bad responses
        return response.text  # This is a basic example; you may need to use a PDF parsing library for a real PDF
    except requests.RequestException as e:
        # Log the error for debugging purposes
        print(f"Error fetching PDF content: {e}")
        return "Summary not found or unable to fetch PDF content."

# Example usage
if __name__ == "__main__":
    pdf_link = "https://example.com/path/to/your.pdf"  # Replacement with the actual PDF link
    pdf_content = FetchPdfDirectly()._run(pdf_link)

    if pdf_content:
        print("PDF content:")
        print(pdf_content)
    else:
        print("Failed to fetch PDF content.")
